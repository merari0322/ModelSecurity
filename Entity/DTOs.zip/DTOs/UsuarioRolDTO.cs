﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Model
{
    class UsuarioRolDTO
    {
        public int Id { get; set; }
        public string UserId1 { get; set; }
        public string RoleId1 { get; set; } 
    }
}
