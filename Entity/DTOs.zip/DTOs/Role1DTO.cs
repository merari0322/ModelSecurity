﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Model
{
    class Role1DTO
    {
        public int Id { get; set; }
        public string TypeRole { get; set; }
    }
}
