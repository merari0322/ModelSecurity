﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Model
{
    class AimDTO
    {
        public int Id { get; set; }
        public string ObjetiveDescription { get; set; }
        public string Innovation { get; set; }
        public string Results { get; set; }
        public string Sustainability { get; set; }
        public string ExperienceId1 { get; set; }
    }
}
